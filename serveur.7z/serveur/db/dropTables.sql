drop table produitcommande;
drop table produit;
drop table commande;
drop table client;