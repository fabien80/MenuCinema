<h1>Serveur Java</h1>
Utilisez MAVEN pour compiler et exécuter ce serveur.

mvn compile

mvn exec:java
